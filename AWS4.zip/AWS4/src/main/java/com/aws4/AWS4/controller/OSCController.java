package com.aws4.AWS4.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.aws4.AWS4.service.OSCService;

@RestController
public class OSCController {

	@Autowired
	OSCService oscService;
	
	@RequestMapping(value= "/osc/contacts/{email}", method = RequestMethod.GET)
	private void buscarOSC(@PathVariable("email") String email) throws Exception {		
		oscService.clientBuscarOSCBorrado(email);
	}
	
	@RequestMapping(value= "/osc/contacts", method = RequestMethod.POST)		
	private void buscarOsCrear(@RequestBody String json) throws Exception {
		oscService.serializarObjecto(json);
	}
}