package com.aws4.AWS4.model;

public class AddressType {
	private int id;

	public AddressType() {
	}

	public AddressType(int id) {
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
}
