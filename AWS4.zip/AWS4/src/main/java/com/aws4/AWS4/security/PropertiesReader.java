package com.aws4.AWS4.security;

import java.util.ResourceBundle;

public class PropertiesReader {
	
	private static final ResourceBundle PROPERTIES = ResourceBundle.getBundle("application");

	public static String getRnUrl(){
        return PROPERTIES.getString("UrlRightNow");
    }
    public static String getRnPass(){
        return PROPERTIES.getString("RightNowAccess");
    }
    public static String getEloquaUrl(){
        return PROPERTIES.getString("UrlEloqua");
    }
    public static String getEloquaPass(){
        return PROPERTIES.getString("EloquaAccess");
    }
    public static String getOscUrl(){
        return PROPERTIES.getString("urlOsc");
    }
    public static String getOscPass(){
        return PROPERTIES.getString("passOsc");
    }
    public static String getEloquaEmail(){
        return PROPERTIES.getString("buscarEloqua");
    }
    public static String getRnEmail(){
        return PROPERTIES.getString("buscarRn");
    }
    public static String getROSCEmail(){
        return PROPERTIES.getString("buscarOSC");
    }   
    public static String CreateRn(){
        return PROPERTIES.getString("crearRn");
    }
    
    public static String CreateEloqua(){
        return PROPERTIES.getString("crearEl");
    }
    
    public static String CreateOsc(){
        return PROPERTIES.getString("crearOsc");
    }
    
    public static String CreateOscLead(){
        return PROPERTIES.getString("crearLead");
    }
    
    public static String BuscarOscLead(){
        return PROPERTIES.getString("buscarOSCLeads");
    }
}
