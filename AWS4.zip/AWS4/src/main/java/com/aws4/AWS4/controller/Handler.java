package com.aws4.AWS4.controller;

import java.io.IOException;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;


public class Handler {

	//CONVERTIR A JSON OBJECT
	public JSONObject JsonObjectContacts (HttpGet request, String email) throws JSONException, ClientProtocolException, IOException {
		String response = ConnectionResponse(request, email);
		JSONObject jo = new JSONObject(response);
		return jo;
	}
	
	//GET
	public String ConnectionResponse (HttpGet request, String email) throws ClientProtocolException, IOException {
		HttpClient client = HttpClientBuilder.create().build();
	    HttpResponse response = client.execute(request);
	    System.out.println("Response Code : " + 
	    	response.getStatusLine().getStatusCode());
		return EntityUtils.toString(response.getEntity());
	}
	
	// DELETE
	public void ConnectionResponse (HttpDelete request, int id) throws ClientProtocolException, IOException {
		HttpClient client = HttpClientBuilder.create().build();
	       HttpResponse response = client.execute(request);
		System.out.println("Response Code : " + response.getStatusLine().getStatusCode());
	}
	
	// DELETE
		public void ConnectionResponse2 (HttpDelete request, long id) throws ClientProtocolException, IOException {
			HttpClient client = HttpClientBuilder.create().build();
		       HttpResponse response = client.execute(request);
			System.out.println("Response Code : " + response.getStatusLine().getStatusCode());
		}
	
	//POST
	public void ConnectionResponse (HttpPost request) throws ClientProtocolException, IOException {
		HttpClient client = HttpClientBuilder.create().build();
		HttpResponse response = client.execute(request);
		System.out.println("RESPUESTA: " + response.toString());
		if(response.getStatusLine().getStatusCode() == 201 || response.getStatusLine().getStatusCode() == 200) {
			System.out.println("Creado correctamente");
		}else {
			System.out.println("Fallo creación de contacto: " + request.toString());
		}
	}	
	
	public String JsonTransformer(String jsonSend) {
        jsonSend = jsonSend.replace("ñ", "n").replace("Ñ", "N")
        .replace("Á", "A").replace("á", "a").replace("É", "E").replace("é", "e").replace("Í", "I").replace("í", "i").replace("Ó", "O").replace("ó", "o").replace("Ú", "U").replace("ú", "u")
        .replace("Ä", "A").replace("ä", "a").replace("Ë", "E").replace("ë", "e").replace("Ï", "I").replace("ï", "i").replace("Ö", "O").replace("ö", "o").replace("Ü", "U").replace("ü", "u");
        return jsonSend;
    }
	
}
