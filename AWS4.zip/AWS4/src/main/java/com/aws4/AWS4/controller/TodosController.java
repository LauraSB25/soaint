package com.aws4.AWS4.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.aws4.AWS4.service.EloquaService;
import com.aws4.AWS4.service.OSCService;
import com.aws4.AWS4.service.RightNowService;

@RestController
public class TodosController {

	@Autowired
	RightNowService rightNowService = new RightNowService();
	
	@Autowired
	EloquaService eloquaService = new EloquaService();
	
	@Autowired
	OSCService oscService = new OSCService();
	
	
	@RequestMapping(value= "/all/crear", method = RequestMethod.POST)		
	private ResponseEntity<String> CrearTodos(@RequestBody String json) {
		return new ResponseEntity<String>(rightNowService.serializarObjecto(json) +
				"\n"+ eloquaService.serializarObjecto(json)+"\n"+oscService.serializarObjecto(json), HttpStatus.OK);				
	}
	
	@RequestMapping(value= "/all/borrar/{email}", method = RequestMethod.DELETE)		
	private ResponseEntity<String> BorrarTodos(@PathVariable("email") String delete) throws Exception {
			return new ResponseEntity<String>(rightNowService.clientBuscarRnBorrado(delete) +
					"\n"+ eloquaService.clientBuscarEloquaBorrado(delete)+"\n"+oscService.clientBuscarOSCBorrado(delete), HttpStatus.OK);
		
					
	}
	
	
}
