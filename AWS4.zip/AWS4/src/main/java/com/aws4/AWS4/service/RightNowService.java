package com.aws4.AWS4.service;

import java.util.Base64;
import org.apache.http.HttpHeaders;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Service;
import com.aws4.AWS4.model.AddressType;
import com.aws4.AWS4.model.ContactRN;
import com.aws4.AWS4.model.Emails;
import com.aws4.AWS4.model.Name;
import com.aws4.AWS4.controller.Handler;
import com.aws4.AWS4.security.PropertiesReader;
import com.fasterxml.jackson.databind.ObjectMapper;


@Service
public class RightNowService {
	
	private String authRn = "Basic " + new String(convert(PropertiesReader.getRnPass()));
	
	Handler h = new Handler();
	
	//Convertir a base64
	public String convert(String pass) {
		String passBase64 = new String(Base64.getEncoder().encode(pass.getBytes()));
		return passBase64;
	}
		
	//***************HTTP CLIENT RIGHT NOW (BUSCAR CLIENTE ELIMINADO)****************//
	public void clientBuscarRnBorrado(String email) throws Exception {
		HttpGet httpGet = new HttpGet(PropertiesReader.getRnEmail() + "'" + h.JsonTransformer(email) + "'");
		httpGet.setHeader(HttpHeaders.AUTHORIZATION, authRn);
		JSONArray items = h.JsonObjectContacts(httpGet, email).getJSONArray("items");
		if(items.length()>0) {
        	for(int i=0;i<items.length();i++) {
        		System.out.println("Cliente encontrado: \tid->"+ items.getJSONObject(i).getInt("id"));
        		clientEliminarRn(items.getJSONObject(i).getInt("id"), email); 
        	}
        }else {
            System.out.println("Cliente NO encontrado: \temail->"+ email);
        }
    }
	//***********HTTP CLIENT RIGHT NOW (DAR DE BAJA)***********//
	public void clientEliminarRn(int id, String email) throws Exception {
		HttpDelete httpDelete = new HttpDelete(PropertiesReader.getRnUrl() + id);
		httpDelete.setHeader(HttpHeaders.AUTHORIZATION, authRn);
		h.ConnectionResponse(httpDelete, id);
		System.out.println("Cliente con email " + email + " se ha borrado correctamente");	
	}
	
	//**********HTTP CLIENT RIGHT NOW (BUSCAR CLIENTE CREADO)*************//
	public boolean clientBuscarRnCreado(String email) throws Exception {
		HttpGet httpGet = new HttpGet(PropertiesReader.getRnEmail() + "'" + h.JsonTransformer(email) + "'");
		httpGet.setHeader(HttpHeaders.AUTHORIZATION, authRn);
		JSONArray items = h.JsonObjectContacts(httpGet, email).getJSONArray("items");
		if(items.length()>0) {
			System.out.println("Cliente encontrado: \tid->"+ items.getJSONObject(0).getInt("id"));
	        return false;
	    }else {
	    	System.out.println("Cliente NO encontrado: \temail->"+ email);
	    	return true;
	    }
	}
	
	//*****HTTP CLIENT RIGHT NOW (SERIALIZAR EL JSON)*****//
	public void serializarObjecto(String jsonSend) {
		JSONObject jsonObject = new JSONObject(jsonSend);
		ContactRN contactRn = new ContactRN() {
			{
				setId(null);
				setName(new Name() {
					{
						setFirst(jsonObject.getString("name"));
						setLast(null);
					}
				});
				setEmails(new Emails() {{
					setAddress(jsonObject.getString("emailAddress"));
					setAddressType(new AddressType() {{
						setId(0);
					}});
				}});
			}
		};
		try {
			if(clientBuscarRnCreado(contactRn.getEmails().getAddress())) {
				String contactJSON = new ObjectMapper().writeValueAsString(contactRn);
				clientCrearRn(contactJSON);
			}		
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//*****HTTP CLIENT RIGHT NOW (DAR DE ALTA)*****//
	public void clientCrearRn(String contactRn) throws Exception {
		HttpPost request = new HttpPost(PropertiesReader.CreateRn());
		StringEntity entity = new StringEntity(contactRn);
		request.setHeader(HttpHeaders.AUTHORIZATION, authRn);
		request.setEntity(entity);
		h.ConnectionResponse(request);	
	}
}
	
