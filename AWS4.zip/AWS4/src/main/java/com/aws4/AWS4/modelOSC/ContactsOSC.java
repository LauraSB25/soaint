
package com.aws4.AWS4.modelOSC;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ContactsOSC {
	
	@JsonIgnore
	private int partyNumber;
	
	@JsonProperty("FirstName")
	private String firstName;
	
	@JsonProperty("LastName")
	private String lastName;
	
	@JsonProperty("EmailAddress")
	private String emailAddress;
	
	public ContactsOSC(){
	}

	public ContactsOSC(String firstName, String lastName, String emailAddress) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailAddress = emailAddress;
	}
	@JsonProperty("FirstName")
	public String getFirstName() {
		return firstName;
	}
	@JsonProperty("FirstName")
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	@JsonProperty("LastName")
	public String getLastName() {
		return lastName;
	}
	@JsonProperty("LastName")
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	@JsonProperty("EmailAddress")
	public String getEmailAddress() {
		return emailAddress;
	}
	@JsonProperty("EmailAddress")
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	@JsonIgnore
	@JsonProperty("PartyNumber")
	public int getPartyNumber() {
		return partyNumber;
	}
	@JsonProperty("PartyNumber")
	public void setPartyNumber(int partyNumber) {
		this.partyNumber = partyNumber;
	}
}

