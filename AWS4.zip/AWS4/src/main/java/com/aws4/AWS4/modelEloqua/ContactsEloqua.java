
package com.aws4.AWS4.modelEloqua;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)

public class ContactsEloqua {
	
	private Object id;
	private String firstname;
	private String lastname;
	private String emailAddress;

    
    public ContactsEloqua() {
	}
    
    public Object getId() {
		return id;
	}

	public void setId(Object id) {
		this.id = id;
	}


	public ContactsEloqua(String firstname, String lastname, String emailAddress) {
		this.firstname = firstname;
		this.lastname = lastname;
		this.emailAddress = emailAddress;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getFirstName() {
		return firstname;
	}

	public void setFirstName(String firstname) {
		this.firstname = firstname;
	}
	
	
    

}
