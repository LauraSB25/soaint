package com.aws4.AWS4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aws4Application {

	public static void main(String[] args) {
		SpringApplication.run(Aws4Application.class, args);
	}

}
