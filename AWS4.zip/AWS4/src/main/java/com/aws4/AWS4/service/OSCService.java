package com.aws4.AWS4.service;

import java.util.Base64;
import org.apache.http.HttpHeaders;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

import com.aws4.AWS4.controller.Handler;
import com.aws4.AWS4.modelOSC.ContactsOSC;
import com.aws4.AWS4.modelOSC.Lead;
import com.aws4.AWS4.security.PropertiesReader;
import com.fasterxml.jackson.databind.ObjectMapper;


@Service
public class OSCService {
	
	private String authOsc = "Basic " + new String(convert(PropertiesReader.getOscPass()));
	
	//Convertir a base64
	public String convert(String pass) {
		String passBase64 = new String(Base64.getEncoder().encode(pass.getBytes()));
		return passBase64;
	}
	
	Handler h = new Handler();
	
	
	public void clientBuscarOSCBorrado(String email) throws Exception {
		HttpGet httpGet = new HttpGet(PropertiesReader.getROSCEmail() + "'" + h.JsonTransformer(email) + "'");
		httpGet.setHeader(HttpHeaders.AUTHORIZATION, authOsc);
		JSONArray items = h.JsonObjectContacts(httpGet, email).getJSONArray("items");
		int partyNumber;
		if(items.length()>0) {
        	for(int i=0;i<items.length();i++) {
        		partyNumber =items.getJSONObject(i).getInt("PartyNumber");
        		System.out.println("Cliente encontrado: \tid->"+ partyNumber);
        		clientBuscarLeadCreado(""+partyNumber);
        		clienteliminarOSC(partyNumber, email); 
        	}
        }else {
            System.out.println("Cliente NO encontrado: \temail->"+ email);
        }
    }
	
	public void clienteliminarOSC(int id, String email) throws Exception {
		HttpDelete httpDelete = new HttpDelete(PropertiesReader.getOscUrl() + id);
		httpDelete.setHeader(HttpHeaders.AUTHORIZATION, authOsc);
		h.ConnectionResponse(httpDelete, id);
		
		System.out.println("Cliente con email " + email + " se ha borrado correctamente");	
	}
	
	public String BuscarOSC(String email) throws Exception {
		HttpGet httpGet = new HttpGet(PropertiesReader.getROSCEmail() + "'" + h.JsonTransformer(email) + "'");
		httpGet.setHeader(HttpHeaders.AUTHORIZATION, authOsc);
		JSONArray items = h.JsonObjectContacts(httpGet, email).getJSONArray("items");
		if(items.length()>0) {
			System.out.println("Cliente encontrado: \tid->"+ items.getJSONObject(0).getInt("PartyNumber"));
	        return items.getJSONObject(0).getString("PartyNumber");
	    }else {
	    	System.out.println("Cliente NO encontrado: \temail->"+ email);
	    }
		return "";
	}
	
	public boolean clientBuscarOSCCreado(String email) throws Exception {
		HttpGet httpGet = new HttpGet(PropertiesReader.getROSCEmail() + "'" + h.JsonTransformer(email) + "'");
		httpGet.setHeader(HttpHeaders.AUTHORIZATION, authOsc);
		JSONArray items = h.JsonObjectContacts(httpGet, email).getJSONArray("items");
		if(items.length()>0) {
			System.out.println("Cliente encontrado: \tid->"+ items.getJSONObject(0).getInt("PartyNumber"));
	        return false;
	    }else {
	    	System.out.println("Cliente NO encontrado: \temail->"+ email);
	    	return true;
	    }
	}
	
	public void serializarObjecto(String jsonSend) {
		JSONObject jsonObject = new JSONObject(jsonSend);
		ContactsOSC contactOsc = new ContactsOSC();
		contactOsc.setFirstName(jsonObject.getString(("firstName")));
		contactOsc.setLastName(jsonObject.getString(("lastName")));
		contactOsc.setEmailAddress(jsonObject.getString(("emailAddress")));
		try {
			if(clientBuscarOSCCreado(contactOsc.getEmailAddress())) {
				String contactJSON = new ObjectMapper().writeValueAsString(contactOsc);
				clientCrearOsc(contactJSON);
				serializarLead(contactJSON);
			}		
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void clientCrearOsc(String contactOsc) throws Exception {
		System.out.println(contactOsc);
		HttpPost request = new HttpPost(PropertiesReader.CreateOsc());
		StringEntity entity = new StringEntity(contactOsc);
		request.setHeader(HttpHeaders.AUTHORIZATION, authOsc);
		request.setHeader("Content-Type","application/json");
		request.setEntity(entity);
		h.ConnectionResponse(request);
	}
	
	
	//**********METODOS PARA EL LEAD*********//
	
	//***********SERIALIZAR LEAD***********//
	public void serializarLead(String jsonLead) throws Exception{
		JSONObject jsonObject = new JSONObject(jsonLead);
		Lead lead = new Lead();
		lead.setName(jsonObject.getString(("EmailAddress")));
		lead.setContactPartyNumber(BuscarOSC(jsonObject.getString("EmailAddress")));
		String leadJSON = new ObjectMapper().writeValueAsString(lead);
		System.out.println("Lead Creado : "+leadJSON);
		crearLead(leadJSON);
		
	}
	
	//*******CREAR LEAD************//
	public void crearLead(String leadJson) throws Exception{
		HttpPost request = new HttpPost(PropertiesReader.CreateOscLead());
		//Lead ld = new Lead();
		ContactsOSC Cosc= new ContactsOSC();		
		request.setHeader(HttpHeaders.AUTHORIZATION, authOsc);
		request.setHeader("Content-Type","application/json");
		StringEntity entity = new StringEntity(leadJson);
		request.setEntity(entity);
		h.ConnectionResponse(request);
	}
	
	public void clientBuscarLeadCreado(String partynumber) throws Exception {
		HttpGet httpGet = new HttpGet(PropertiesReader.BuscarOscLead() + partynumber);
		httpGet.setHeader(HttpHeaders.AUTHORIZATION, authOsc);
		JSONArray items = h.JsonObjectContacts(httpGet, partynumber).getJSONArray("items");
		for(int i=0;i<items.length();i++) {
			clienteliminarOSCLead(items.getJSONObject(i).getLong("LeadId"));
			System.out.println("Cliente encontrado: \tid->"+ partynumber);
		}
	}
	
	public void clienteliminarOSCLead(long leadid) throws Exception {
		System.out.println("URL "+PropertiesReader.CreateOscLead() +"/"+ leadid);
		HttpDelete httpDelete = new HttpDelete(PropertiesReader.CreateOscLead() +"/"+ leadid);
		httpDelete.setHeader(HttpHeaders.AUTHORIZATION, authOsc);
		h.ConnectionResponse2(httpDelete, leadid);
		
		System.out.println("Lead " + leadid + " se ha borrado correctamente");	
	}
	
	
	
	
	
	

}
