package com.aws4.AWS4.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.aws4.AWS4.service.RightNowService;

@RestController
public class RightNowController {

	@Autowired
	RightNowService rightNowService;
	
	@RequestMapping(value= "/rn/contacts/{email}", method = RequestMethod.GET)
	private void buscarRn(@PathVariable("email") String email) throws Exception {
		rightNowService.clientBuscarRnBorrado(email);
	}
	
	@RequestMapping(value= "/rn/contacts", method = RequestMethod.POST)		
	private void buscarRnCrear(@RequestBody String json) throws Exception {
		System.out.println("PRUEBA "+json);
		rightNowService.serializarObjecto(json);
	}
	
}
